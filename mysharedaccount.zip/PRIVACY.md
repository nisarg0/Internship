# Privacy Policy

Your privacy is important to us. It our policy to respect your privacy regarding any information you have.

ShareAccount is a non-profit open source project, Github. No data or personal information is collected by ShareAccount. By installing the extension you give it permission to read personal information on your site. This information will be then encrypted and presented back to the user, without storing anything.

### THIRD PARTY ANALYTICS PROVIDERS, AD SERVERS AND SIMILAR THIRD PARTIES

We may work with advertising agencies and vendors who use technology to help us understand how people use our Site. These vendors may use technologies to serve you advertisements that may interest you. You can choose to opt out of receiving interest-based advertising.

ShareAccount uses [Google Analytics](https://analytics.google.com/analytics/web/) to provide us with information regarding traffic on the Service, including pages viewed and the actions taken when visiting the Service. We do not fingerprint our users and don't have a way to tell which account used the app. Google Analytics may collect certain information about your visits to and activity on the Service as well as other websites or services, they may set and access their own tracking technologies (including cookies and web beacons), and may use that information to show you targeted advertisements.
You can read more about how Google processes your data at https://policies.google.com/technologies/partner-sites


##### Contact

If you have any questions or suggestions regarding this privacy policy, do not hesitate to [contact me](mailto:santangelonicolas@gmail.com).
