// Easy access to log functions to be disabled on build
window.log = console.log.bind(console, '[ShareAccount]')
